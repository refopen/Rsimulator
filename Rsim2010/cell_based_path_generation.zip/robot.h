#ifndef __ROBOT_H__
#define __ROBOT_H__

class CDrawView;

class CRobotControl
{
// Construction
public:
	CRobotControl();

// Attributes
public:

// Operations
public:

// Implementation
public:
	BOOL m_bChecked[150][150];
	BOOL Recursion(int i, int j, int Width, int Height, BOOL direction);
	BOOL Iterative(int i, int j, int Width, int Height);
	BOOL SizeOfObstacle(int n, int m, int i[2]);
	void MoveTo(CDrawView *pView, double x, double y);
	int vl;
	int vr;
	void Update(CDrawView *pView);
	int angle;
	CPoint goal;
	int m_nTable[150][150];
	virtual ~CRobotControl();
 
protected:
};

#endif // _ROBOT_H__